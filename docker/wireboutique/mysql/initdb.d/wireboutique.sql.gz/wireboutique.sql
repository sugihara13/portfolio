-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- ホスト: 127.0.0.1
-- 生成日時: 2025-05-27 04:06:58
-- サーバのバージョン： 10.4.32-MariaDB
-- PHP のバージョン: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- データベース: `wireboutique1`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `admin_users`
--

CREATE TABLE `admin_users` (
  `ADMIN_USER_ID` varchar(32) NOT NULL,
  `PASSWORD` varchar(100) NOT NULL,
  `ROLE_ID` smallint(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `admin_users`
--

INSERT INTO `admin_users` (`ADMIN_USER_ID`, `PASSWORD`, `ROLE_ID`) VALUES
('administrator', '$SHA-256$cbBGZlY1QrzaQQ/T/lrjOiAh/guYlFcctud4vlBUkd0$Q4WdvbLHwu9SI6GcN6we6DICpH4TVkeOzdZWHmnWobM', 1);

-- --------------------------------------------------------

--
-- テーブルの構造 `admin_user_permissions`
--

CREATE TABLE `admin_user_permissions` (
  `ROLE_ID` smallint(6) NOT NULL,
  `ENTER_SERVICE_MGR` tinyint(1) NOT NULL DEFAULT 0,
  `EDIT_ADMIN_USER_PERMISSIONS` tinyint(1) NOT NULL DEFAULT 0,
  `MANAGE_PRODUCT_DATA` tinyint(1) NOT NULL DEFAULT 0,
  `MANAGE_PRODUCT_RESOURCE` tinyint(1) NOT NULL DEFAULT 0,
  `ADD_PRODUCT` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `admin_user_permissions`
--

INSERT INTO `admin_user_permissions` (`ROLE_ID`, `ENTER_SERVICE_MGR`, `EDIT_ADMIN_USER_PERMISSIONS`, `MANAGE_PRODUCT_DATA`, `MANAGE_PRODUCT_RESOURCE`, `ADD_PRODUCT`) VALUES
(0, 0, 0, 0, 0, 0),
(1, 1, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- テーブルの構造 `admin_user_roles`
--

CREATE TABLE `admin_user_roles` (
  `ROLE_ID` smallint(6) NOT NULL,
  `ROLE_NAME` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `admin_user_roles`
--

INSERT INTO `admin_user_roles` (`ROLE_ID`, `ROLE_NAME`) VALUES
(1, 'Administrator'),
(0, 'None');

-- --------------------------------------------------------

--
-- テーブルの構造 `categories`
--

CREATE TABLE `categories` (
  `CATEGORY_ID` int(11) NOT NULL,
  `CATEGORY` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `categories`
--

INSERT INTO `categories` (`CATEGORY_ID`, `CATEGORY`) VALUES
(1, 'Effect'),
(2, 'Sample');

-- --------------------------------------------------------

--
-- テーブルの構造 `manufacturers`
--

CREATE TABLE `manufacturers` (
  `MANUFACTURER_ID` int(11) NOT NULL,
  `MANUFACTURER` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `manufacturers`
--

INSERT INTO `manufacturers` (`MANUFACTURER_ID`, `MANUFACTURER`) VALUES
(1, 'Awire'),
(2, 'BWire'),
(3, 'DWire'),
(4, 'EWire'),
(5, 'GWire'),
(8, 'Iwire'),
(9, 'KWire'),
(6, 'TWire'),
(7, 'ZWire');

-- --------------------------------------------------------

--
-- テーブルの構造 `orders`
--

CREATE TABLE `orders` (
  `ORDER_ID` varchar(26) NOT NULL,
  `TOTAL_PRICE` decimal(11,2) NOT NULL,
  `ORDER_DATE` datetime NOT NULL DEFAULT '1900-01-01 00:00:00',
  `PAYMENT_STATE` varchar(30) NOT NULL,
  `PAYMENT_METHODE` varchar(30) NOT NULL,
  `USER_ID` varchar(32) NOT NULL,
  `PURCHASER` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- テーブルの構造 `order_details`
--

CREATE TABLE `order_details` (
  `ORDER_ID` varchar(26) NOT NULL,
  `PRODUCT_ID` int(11) NOT NULL,
  `PRODUCT_NAME` text NOT NULL,
  `PURCHASE_PRICE` decimal(11,2) NOT NULL,
  `QUANTITY` int(11) NOT NULL,
  `TAX_RATE` decimal(4,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- テーブルの構造 `products`
--

CREATE TABLE `products` (
  `PRODUCT_ID` int(10) NOT NULL DEFAULT 0,
  `UPDATED_AT` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `CREATED_AT` datetime NOT NULL DEFAULT current_timestamp(),
  `NAME` text NOT NULL DEFAULT ('UNNAMED'),
  `CATEGORY_ID` int(11) NOT NULL,
  `MANUFACTURER_ID` int(11) NOT NULL,
  `LIST_PRICE` decimal(10,2) NOT NULL DEFAULT 0.00,
  `RELEASE_DATE` date NOT NULL DEFAULT '1900-01-01',
  `CONTENTS` text DEFAULT NULL,
  `TAX_CATEGORY_ID` tinyint(4) NOT NULL DEFAULT 0,
  `STOCK` int(11) DEFAULT 0,
  `IS_PUBLIC` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `products`
--

INSERT INTO `products` (`PRODUCT_ID`, `UPDATED_AT`, `CREATED_AT`, `NAME`, `CATEGORY_ID`, `MANUFACTURER_ID`, `LIST_PRICE`, `RELEASE_DATE`, `CONTENTS`, `TAX_CATEGORY_ID`, `STOCK`, `IS_PUBLIC`) VALUES
(1, '2025-04-15 12:06:47', '1970-01-01 00:00:00', 'UNNAMED', 0, 0, 0.00, '1900-01-01', NULL, 0, 0, 1),
(2, '2025-04-15 12:06:47', '1970-01-01 00:00:00', 'Alpha', 1, 1, 111.00, '2010-01-01', 'WEB-INF/Assets/products/2/contents/', 1, 0, 1),
(3, '2025-04-15 12:06:47', '1970-01-01 00:00:00', 'Beta', 1, 2, 200.00, '2011-02-10', 'WEB-INF/Assets/products/3/contents/', 1, NULL, 1),
(4, '2025-05-14 11:38:55', '1970-01-01 00:00:00', 'Gamma  ', 1, 5, 300.00, '2030-03-10', 'WEB-INF/Assets/products/4/contents/', 1, NULL, 1),
(5, '2025-05-08 13:13:11', '1970-01-01 00:00:00', 'Delta', 1, 3, 500.00, '2013-05-08', 'WEB-INF/Assets/products/5/contents/', 1, NULL, 1),
(6, '2025-05-13 12:22:44', '1970-01-01 00:00:00', 'Epsilon  ', 1, 4, 500.00, '2028-03-10', 'WEB-INF/Assets/products/6/contents/', 1, NULL, 0),
(7, '2025-04-15 12:06:47', '1970-01-01 00:00:00', 'Zeta', 1, 7, 500.00, '2012-05-10', 'WEB-INF/Assets/products/7/contents/', 2, NULL, 1),
(8, '2025-04-15 12:06:47', '1970-01-01 00:00:00', 'Eta', 1, 4, 700.00, '2013-08-13', 'WEB-INF/Assets/products/8/contents/', 1, NULL, 1),
(9, '2025-04-15 12:06:47', '1970-01-01 00:00:00', 'Theta', 1, 6, 700.00, '2014-08-02', 'WEB-INF/Assets/products/9/contents/', 1, NULL, 1),
(10, '2025-04-15 12:06:47', '1970-01-01 00:00:00', 'Iota', 1, 8, 0.00, '2018-09-05', 'WEB-INF/Assets/products/10/contents/', 0, NULL, 1),
(11, '2025-04-15 12:06:47', '1970-01-01 00:00:00', 'Kappa', 1, 9, 920.00, '2023-08-01', 'WEB-INF/Assets/products/11/contents/', 1, NULL, 1);

-- --------------------------------------------------------

--
-- テーブルの構造 `product_logs`
--

CREATE TABLE `product_logs` (
  `PRODUCT_LOG_ID` bigint(20) NOT NULL DEFAULT 0,
  `PRODUCT_ID` int(10) NOT NULL DEFAULT 0,
  `UPDATED_AT` datetime NOT NULL,
  `NAME` text NOT NULL DEFAULT ('UNNAMED'),
  `CATEGORY_ID` int(11) NOT NULL,
  `MANUFACTURER_ID` int(11) NOT NULL,
  `LIST_PRICE` decimal(10,2) NOT NULL DEFAULT 0.00,
  `RELEASE_DATE` date NOT NULL DEFAULT '1900-01-01',
  `CONTENTS` text DEFAULT NULL,
  `TAX_CATEGORY_ID` tinyint(4) NOT NULL DEFAULT 0,
  `STOCK` int(11) DEFAULT 0,
  `IS_PUBLIC` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `product_logs`
--

INSERT INTO `product_logs` (`PRODUCT_LOG_ID`, `PRODUCT_ID`, `UPDATED_AT`, `NAME`, `CATEGORY_ID`, `MANUFACTURER_ID`, `LIST_PRICE`, `RELEASE_DATE`, `CONTENTS`, `TAX_CATEGORY_ID`, `STOCK`, `IS_PUBLIC`) VALUES
(1, 1, '2025-05-23 06:53:26', 'UNNAMED', 0, 0, 0.00, '1900-01-01', NULL, 0, 0, 0);

-- --------------------------------------------------------

--
-- テーブルの構造 `tax_categories`
--

CREATE TABLE `tax_categories` (
  `TAX_CATEGORY_ID` tinyint(4) NOT NULL,
  `TAX_NAME` varchar(50) NOT NULL,
  `TAX_RATE` decimal(4,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `tax_categories`
--

INSERT INTO `tax_categories` (`TAX_CATEGORY_ID`, `TAX_NAME`, `TAX_RATE`) VALUES
(0, 'NON_TAX_RATE', 0.00),
(1, 'REGULAR_TAX', 0.10),
(2, 'REDUCED_RATE_TAX', 0.08);

-- --------------------------------------------------------

--
-- テーブルの構造 `users`
--

CREATE TABLE `users` (
  `USER_ID` varchar(32) NOT NULL,
  `PASSWORD` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- ダンプしたテーブルのインデックス
--

--
-- テーブルのインデックス `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`ADMIN_USER_ID`);

--
-- テーブルのインデックス `admin_user_permissions`
--
ALTER TABLE `admin_user_permissions`
  ADD PRIMARY KEY (`ROLE_ID`);

--
-- テーブルのインデックス `admin_user_roles`
--
ALTER TABLE `admin_user_roles`
  ADD PRIMARY KEY (`ROLE_ID`),
  ADD UNIQUE KEY `ROLE_NAME` (`ROLE_NAME`);

--
-- テーブルのインデックス `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`CATEGORY_ID`),
  ADD UNIQUE KEY `CATEGORY` (`CATEGORY`);

--
-- テーブルのインデックス `manufacturers`
--
ALTER TABLE `manufacturers`
  ADD PRIMARY KEY (`MANUFACTURER_ID`),
  ADD UNIQUE KEY `MANUFACTURER` (`MANUFACTURER`);

--
-- テーブルのインデックス `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`ORDER_ID`);

--
-- テーブルのインデックス `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`PRODUCT_ID`),
  ADD UNIQUE KEY `ID` (`PRODUCT_ID`);

--
-- テーブルのインデックス `product_logs`
--
ALTER TABLE `product_logs`
  ADD PRIMARY KEY (`PRODUCT_LOG_ID`),
  ADD KEY `PRODUCT_ID` (`PRODUCT_ID`);

--
-- テーブルのインデックス `tax_categories`
--
ALTER TABLE `tax_categories`
  ADD PRIMARY KEY (`TAX_CATEGORY_ID`);

--
-- テーブルのインデックス `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`USER_ID`);

--
-- ダンプしたテーブルの制約
--

--
-- テーブルの制約 `product_logs`
--
ALTER TABLE `product_logs`
  ADD CONSTRAINT `product_logs_ibfk_1` FOREIGN KEY (`PRODUCT_ID`) REFERENCES `products` (`PRODUCT_ID`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
